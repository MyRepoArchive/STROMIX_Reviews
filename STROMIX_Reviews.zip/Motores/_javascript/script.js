var imgMenu = document.getElementById('menuImg')
function mudaFoto(foto) {
    imgMenu.src = foto
}